import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:parents_app/constants/constants.dart';
import 'package:parents_app/dbHandler/FireStore_Important/firestoreCollectionNames.dart';
import 'package:parents_app/dbHandler/FireStore_Important/firestoreDocumentNames.dart';
import 'package:parents_app/dbHandler/assistant_methods.dart';
import 'package:parents_app/screens/subPages/addSafeZoneScreen.dart';
import 'package:parents_app/utils/Utils.dart';

class ChildLocationPage extends StatefulWidget {
  const ChildLocationPage({Key? key}) : super(key: key);

  @override
  State<ChildLocationPage> createState() => _ChildLocationPageState();
}

class _ChildLocationPageState extends State<ChildLocationPage> {

  bool isChildInSafeZone=true;


  // child live location tracking process
  LatLng? child_coordinates;
  Future<void> mymap(AsyncSnapshot<DocumentSnapshot> snapshot) async {
    var ChildDocumentStreamData = snapshot.data;

    debugPrint(
        'DATA FROM DOCUMENT ${ChildDocumentStreamData?['current_geo_location']['latitude']} ,,, ${ChildDocumentStreamData?['current_geo_location']['longitude']}');

     child_coordinates = LatLng(
        ChildDocumentStreamData?['current_geo_location']['latitude'],
        ChildDocumentStreamData?['current_geo_location']['longitude']);

    // ---------- Adding the live location on the map ----------------------------
    Marker child_live_location = Marker(
      markerId: MarkerId('99'),
      position: child_coordinates!,
      infoWindow: InfoWindow(
        title: '${tappedChildObject!.name}',
        snippet: "Live Location of your child",
      ),
      icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueMagenta),
    );

    _markers.add(child_live_location);
  }

  // ========================= Adding the Custom Maker for each of the safe zone added for the child ==============================
  final List<Marker> _markers = <Marker>[];
  final List<LatLng> _latLang = <LatLng>[];

  // add new marker
  addNewSafeZoneMarker(
      int index, LatLng safeZoneCoordinates, String title, description) {
    _latLang.add(safeZoneCoordinates);
    _markers.add(
      Marker(
        markerId: MarkerId(index.toString()),
        position: safeZoneCoordinates,
        infoWindow: InfoWindow(
          title: title,
          snippet: description,
        ),
      ),
    );
  }

  popSafeZoneMarker(int index) {
    _markers.removeAt(index);
  }

  // for testing only
  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(33.6910, 72.98072),
    zoom: 15,
  );

  //Setting up the google map controller that will listen to the changes occurring in the google map
  Completer<GoogleMapController> _controller = Completer();
  GoogleMapController? newGoogleMapController;

  //Height of the white container that displays the safe zone for the child we have tapped
  double safeZoneContainerHeight = 220;

  //------------- Stuff Related To Safe Zone Marker ----------------------------

  // this object store the current position of the parent device
  Position? parentCurrentLocation;

  // initialing the Geo Locator Package Object
  var geoLocator = Geolocator();

  //getting user permission for the location services
  checkIfPermissionAllowed() async {
    LocationPermission permission;
    bool serviceEnabled;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // Permissions are denied, next time you could try
        // requesting permissions again (this is also where
        // Android's shouldShowRequestPermissionRationale
        // returned true. According to Android guidelines
        // your App should show an explanatory UI now.
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    return serviceEnabled;
  }

  // get the user current geo coordinates
  locateUserPosition() async {
    checkIfPermissionAllowed();
    //move camera along the lat long
    Position current_position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    parentCurrentLocation = current_position;

    debugPrint("My Current Location is ${current_position.longitude}");

    LatLng latLngPosition =
        LatLng(current_position!.latitude, current_position!.longitude);
    CameraPosition cameraPosition =
        CameraPosition(target: latLngPosition, zoom: 14);
    newGoogleMapController!
        .animateCamera(CameraUpdate.newCameraPosition(cameraPosition));

    setState(() {

    });
  }

  _refresh_screen(){

    for(int i =0;i< _latLang.length;i++){
      if(_latLang[i].longitude == child_coordinates!.longitude && _latLang[i].latitude == child_coordinates!.latitude){
        isChildInSafeZone=true;
      }
      else{
        isChildInSafeZone =false;
      }
    }

    setState(() {

    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
            '${tappedChildObject!.name} , Age : ${tappedChildObject!.age}'),
        actions: [
          TextButton(
            onPressed: _refresh_screen,
            child: Text('Refresh',style: TextStyle(color: Colors.white70),),
          )
        ],
      ),
      body: SafeArea(
        child: Stack(
          children: [
            // Google Maps Setting
            GoogleMap(
              initialCameraPosition: _kGooglePlex,
              mapType: MapType.normal,
              myLocationButtonEnabled: true,
              myLocationEnabled: true,
              compassEnabled: true,
              markers: Set<Marker>.of(_markers),
              onMapCreated: (GoogleMapController gmapController) {
                _controller.complete(gmapController);
                newGoogleMapController = gmapController;
                locateUserPosition();
                setState(() {
                  _markers;
                });
              },
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                child: FloatingActionButton(
                  backgroundColor: isChildInSafeZone ? Colors.green: Colors.red,
                  child: Icon(Icons.safety_check,),
                  onPressed: (){
                    CameraPosition cameraPosition =
                        CameraPosition(
                            target: child_coordinates!, zoom: 14);
                        newGoogleMapController!.animateCamera(
                            CameraUpdate.newCameraPosition(
                                cameraPosition));
                  },
                ),
              ),
            ),
            StreamBuilder(
              stream: childDocumentReference!.snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<DocumentSnapshot> snapshot) {
                if (snapshot.hasData && snapshot.data != null) {
                  mymap(snapshot);
                  return SizedBox(
                    width: 10,
                  );
                } else {
                  return CircularProgressIndicator();
                }
              },
            ),

            // This is the white box that contains the safe zone details of the tapped child

            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: AnimatedSize(
                curve: Curves.easeInSine,
                duration: const Duration(milliseconds: 120),
                child: Container(
                  height: safeZoneContainerHeight,
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(20),
                          topLeft: Radius.circular(20))),
                  child: StreamBuilder(
                    stream: childDocumentReference!
                        .collection(
                            FireStoreCollectionNames.CHILD_SAFE_ZONE_COLLECTION)
                        .snapshots(),
                    builder: (BuildContext context,
                        AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>>
                            snapshot) {
                      if (snapshot.hasData && snapshot.data != null) {
                        // to check total number of documents
                        debugPrint(
                            'Total Sub Collection Documents Safe Zone : ${snapshot.data!.docs.length}');

                        // checking if the collection has a data then come here
                        if (snapshot.data!.docs.isNotEmpty) {
                          //  make sure that document has the data
                          return ListView.separated(
                              itemBuilder: (_, int index) {
                                // **************** METHOD # 1 of FETCHING DATA ************************************************************
                                /*
                                * in method one we will dump the entire collection data
                                * */
                                Map<String, dynamic> docData = snapshot
                                    .data!.docs[index]
                                    .data(); // dump all the data in the docData map from the collection
                                // checking if the document is the emypt
                                if (docData.isEmpty) {
                                  return const Center(
                                      child: Text("Document is empty"));
                                }

                                // add the loaded safe zone the the markers list
                                LatLng coordinates = LatLng(
                                    double.parse(docData[
                                        DocumentFields.safezone_latitude]),
                                    double.parse(docData[
                                        DocumentFields.safezone_longitude]));
                                addNewSafeZoneMarker(
                                    index,
                                    coordinates,
                                    docData[DocumentFields.safezone_title],
                                    docData[
                                        DocumentFields.safezone_description]);

                                return ListTile(
                                  title: Text(
                                      docData[DocumentFields.safezone_title]),
                                  subtitle: Text(
                                      '${docData[DocumentFields.safezone_description]} \nLatitude ${docData[DocumentFields.safezone_latitude]} and Longitude ${docData[DocumentFields.safezone_longitude]} '),
                                  trailing: const Icon(Icons.location_on),
                                  onTap: () async {
                                    double lat = double.parse(docData[
                                        DocumentFields.safezone_latitude]);

                                    double long = double.parse(docData[
                                        DocumentFields.safezone_longitude]);

                                    LatLng latLngPosition = LatLng(lat, long);
                                    debugPrint(
                                        latLngPosition.longitude.toString());
                                    CameraPosition cameraPosition =
                                        CameraPosition(
                                            target: latLngPosition, zoom: 14);
                                    newGoogleMapController!.animateCamera(
                                        CameraUpdate.newCameraPosition(
                                            cameraPosition));

                                    debugPrint(index.toString());
                                    setState(() {});
                                  },
                                  onLongPress: () async {
                                    LatLng coordinates = LatLng(
                                        double.parse(docData[
                                            DocumentFields.safezone_latitude]),
                                        double.parse(docData[DocumentFields
                                            .safezone_longitude]));
                                    var safe_zones_document_reference =
                                        childDocumentReference!.collection(
                                            FireStoreCollectionNames
                                                .CHILD_SAFE_ZONE_COLLECTION);

                                    var documentName =
                                        "${coordinates.latitude} : ${coordinates.longitude}";
                                    debugPrint(documentName);

                                    await safe_zones_document_reference
                                        .doc(documentName)
                                        .delete()
                                        .then((value) {
                                      Utils().toastMessage("Safe Zone Deleted");
                                    });
                                    setState(() {
                                      popSafeZoneMarker(index);
                                      locateUserPosition();
                                    });
                                  },
                                );
                              },
                              separatorBuilder: (_, __) {
                                return const Divider();
                              },
                              itemCount: snapshot.data!.docs.length);
                        } else {
                          //document does not has data
                          return const Center(
                            child:
                                Text('No Safe Zone is added by the parent yet'),
                          );
                        }
                      } else {
                        /*
              * if the collection does not has data flow come here and we will display no data to user on screen
              * */
                        return const Center(
                          child:
                              Text('No Safe Zone is added by the parent yet'),
                        );
                      }
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),

      // This floating button will route us to the add new safe zone for the child screen
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const AddSafeZoneScreen()));
          setState(() {});
        },
        child: const Icon(Icons.add),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,

    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      _markers;
      AssistantMethods.readTappedChildInformation();
    });
  }
}
