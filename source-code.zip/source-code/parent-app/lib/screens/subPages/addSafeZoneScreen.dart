import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:parents_app/constants/constants.dart';
import 'package:parents_app/google_map_api/google_map_api_key.dart';
import 'package:parents_app/utils/Utils.dart';
import 'package:uuid/uuid.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../dbHandler/FireStore_Important/firestoreDocumentNames.dart';

class AddSafeZoneScreen extends StatefulWidget {
  const AddSafeZoneScreen({Key? key}) : super(key: key);

  @override
  State<AddSafeZoneScreen> createState() => _AddSafeZoneScreenState();
}

class _AddSafeZoneScreenState extends State<AddSafeZoneScreen> {
  late String latitude_selected_safeZone = '-';
  late String longitude_selected_safeZone = '';
  late String location_title ='-';

  /*
  *   Using google maps api search the places to get the safe zone
  *
  * */
  var _controller = TextEditingController();

  String _selectedLocation = '?';
  String _cordinatesAre = "?";
  TextEditingController locationTitleController =TextEditingController();

  var uuid = new Uuid(); //get device unique id for the server

  String _sessionToken = '1234567890';
  List<dynamic> _placeList = [];

  @override
  void initState() {
    super.initState();
    _controller.addListener(() {
      _onChanged();
    });
  }

  _onChanged() {
    if (_sessionToken == null) {
      setState(() {
        _sessionToken = uuid.v4();
      });
    }
    getSuggestion(_controller.text);
  }

  void getSuggestion(String input) async {
    String kPLACES_API_KEY = "your api";
    String type = '(regions)';

    try {
      String baseURL =
          'https://maps.googleapis.com/maps/api/place/autocomplete/json';
      String request =
          '$baseURL?input=$input&key=${kgoogle_map_api_key}&sessiontoken=$_sessionToken';
      var response = await http.get(Uri.parse(request));
      var data = json.decode(response.body);
      // print('mydata');
      // print(data);
      if (response.statusCode == 200) {
        setState(() {
          _placeList = json.decode(response.body)['predictions'];
        });
      } else {
        throw Exception('Failed to load predictions');
      }
    } catch (e) {
      // toastMessage('success');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Hello"),
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              height: 35,
            ),
            Text(
              'Add A Safe Zone For Your Child',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(
              height: 35,
            ),
            TextField(
              controller: locationTitleController,
              decoration: InputDecoration(
                hintText: 'Enter the Title of Safe Zone',
              ),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: TextField(
                controller: _controller,
                decoration: InputDecoration(
                  hintText: "Type The Keywords for the safe zone",
                  focusColor: Colors.white,
                  floatingLabelBehavior: FloatingLabelBehavior.never,
                  prefixIcon: Icon(Icons.location_on),
                  suffixIcon: IconButton(
                    icon: Icon(Icons.cancel),
                    onPressed: () {
                      _controller.clear();
                      setState(() {
                        _selectedLocation = '-';
                        _cordinatesAre = '-';
                      });
                    },
                  ),
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: _placeList.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () async {
                      _selectedLocation = _placeList[index]['description'];
                      List<Location> locations =
                          await locationFromAddress(_selectedLocation);

                      setState(() {
                        _controller.text = _selectedLocation;

                        _cordinatesAre = locations.last.latitude.toString() +
                            " : " +
                            locations.last.longitude.toString();

                        debugPrint(_cordinatesAre);

                        longitude_selected_safeZone =
                            locations.last.longitude.toString();
                        latitude_selected_safeZone =
                            locations.last.latitude.toString();

                        debugPrint(longitude_selected_safeZone);
                        debugPrint(latitude_selected_safeZone);

                      });
                    },
                    child: ListTile(
                      title: Text(_placeList[index]["description"]),
                      trailing: Icon(Icons.location_on),
                    ),
                  );
                },
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Text("You Selected Safe zone is : ${_selectedLocation}"),
            SizedBox(
              height: 10,
            ),
            Text("You Selected Safe zone Cordinates is : ${_cordinatesAre}"),
            SizedBox(
              height: 25,
            ),
            ElevatedButton(
                onPressed: () async {
                  location_title=locationTitleController.text.toString();
                  if (latitude_selected_safeZone == '-' ||
                      longitude_selected_safeZone == '-' || location_title =='-' ) {
                    debugPrint("I am failded");
                    Utils().toastMessage(
                        "Please First Select Location then tap button");
                  } else {
                    debugPrint("I am In Add Safe Zone");

                    await childDocumentReference!
                        .get()
                        .then((DocumentSnapshot snapshot) {
                      if (snapshot.exists) {
                        final data = snapshot.data() as Map<String, dynamic>;
                        print(data[DocumentFields.child_name]);
                      }
                    });

                    debugPrint('latitude ${latitude_selected_safeZone} and longitude ${longitude_selected_safeZone}');
                    childDocumentReference!
                        .collection('safe-zones')
                        .doc(_cordinatesAre)
                        .set({
                      'title':location_title,
                      'description': _selectedLocation,
                      'lat': latitude_selected_safeZone,
                      'long': longitude_selected_safeZone
                    });

                    Navigator.pop(context);
                  }
                },
                child: Text("Add A New Safe Zone For The Child")),
          ],
        ),
      ),
    );
  }
}
