import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:parents_app/dbHandler/FireStore_Important/firestoreCollectionNames.dart';
import 'package:parents_app/dbHandler/assistant_methods.dart';
import 'package:parents_app/screens/subPages/childLocationPage.dart';
import 'package:parents_app/utils/Utils.dart';

import '../../constants/constants.dart';
import '../../dbHandler/FireStore_Important/firestoreDocumentNames.dart';
import '../../widgets/progress_dialog.dart';

class HomeTabPage extends StatefulWidget {
  const HomeTabPage({Key? key}) : super(key: key);

  @override
  State<HomeTabPage> createState() => _HomeTabPageState();
}

class _HomeTabPageState extends State<HomeTabPage> {
  //============ Process of tracking the child current location ==================================================



  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('parents')
            .doc(kfirebaseAuthenticationInstance.currentUser!.email.toString())
            .collection('children')
            .snapshots(),
        builder: (BuildContext context,
            AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>> snapshot) {
          if (snapshot.hasData && snapshot.data != null) {
            // to check total number of documents
            debugPrint(
                'Total Sub Collection Documents : ${snapshot.data!.docs.length}');

            // checking if the collection has a data then come here
            if (snapshot.data!.docs.isNotEmpty) {
              //  make sure that document has the data
              return ListView.separated(
                  itemBuilder: (_, int index) {
                    // **************** METHOD # 1 of FETCHING DATA ************************************************************
                    /*
                    * in method one we will dump the entire collection data
                    * */
                    Map<String, dynamic> docData = snapshot.data!.docs[index]
                        .data(); // dump all the data in the docData map from the collection
                    // checking if the document is the emypt
                    if (docData.isEmpty) {
                      return Center(child: Text("Document is empty"));
                    }

                    return ListTile(
                      title: Text(docData['child_name']),
                      subtitle: Text(docData['child_email']),
                      trailing: Text(docData['child_pin']),
                      onTap: () async {

                        //----- show loading progress ////
                        showDialog(
                            context: context,
                            barrierDismissible: false,
                            builder: (BuildContext context) {
                              return ProgressDialog(message: 'Processing Please Wait.....');
                            });



                        childDocumentReference = FirebaseFirestore.instance
                            .collection(
                                FireStoreCollectionNames.PARENTS_COLLECTION)
                            .doc(currentLoggedInParent!.email)
                            .collection(
                                FireStoreCollectionNames.CHILDREN_COLLECTION)
                            .doc(docData['child_email']);
                        currentChildEmailAddress = docData['child_email'];

                        debugPrint('current child geo-cordinates ${docData['current_geo_location'].toString()}');

                        if (childDocumentReference != null) {
                          AssistantMethods.readTappedChildInformation();
                          Timer(Duration(seconds: 1), () {

                            Navigator.pop(context);
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ChildLocationPage()));
                          });
                        }
                      },

                      // if long press is trigger than delete the child from database and list tile view
                      onLongPress: () async {
                        var children_collection = FirebaseFirestore.instance
                            .collection('parents')
                            .doc(kfirebaseAuthenticationInstance
                                .currentUser!.email
                                .toString())
                            .collection('children');

                        debugPrint('Children Email Deteleing ${docData['child_email']}');
                        await children_collection.doc(docData[DocumentFields.child_email]).delete().then((value) => Utils().toastMessage("Selected Child Deleted")).onError((error, stackTrace) => Utils().toastMessage(error.toString()));

                        setState(() {});
                      },
                    );
                  },
                  separatorBuilder: (_, __) {
                    return const Divider();
                  },
                  itemCount: snapshot.data!.docs.length);
            } else {
              //document does not has data
              return Center(
                child: Text('Collection has no data'),
              );
            }
          } else {
            /*
              * if the collection does not has data flow come here and we will display no data to user on screen
              * */
            return Center(
              child: Text('Collection has no data'),
            );
          }
        },
      ),
    );
  }
}
