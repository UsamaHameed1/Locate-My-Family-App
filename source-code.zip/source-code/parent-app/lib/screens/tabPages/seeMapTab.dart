import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../constants/constants.dart';
import '../../dbHandler/FireStore_Important/firestoreCollectionNames.dart';
import '../../dbHandler/FireStore_Important/firestoreDocumentNames.dart';
import '../../dbHandler/assistant_methods.dart';
import '../../utils/Utils.dart';
import '../../widgets/progress_dialog.dart';
import '../subPages/childLocationPage.dart';

class SeeMapTabPage extends StatefulWidget {
  const SeeMapTabPage({Key? key}) : super(key: key);

  @override
  State<SeeMapTabPage> createState() => _SeeMapTabPageState();
}

class _SeeMapTabPageState extends State<SeeMapTabPage> {


  // ========================= Adding the Custom Maker  the child ==============================
  final List<Marker> _markers = <Marker>[];
  final List<LatLng> _latLang = <LatLng>[];

  // add new marker
  addNewSafeZoneMarker(
      int index, LatLng safeZoneCoordinates, String title, description) {
    _latLang.add(safeZoneCoordinates);
    _markers.add(
      Marker(
        markerId: MarkerId(index.toString()),
        position: safeZoneCoordinates,
        infoWindow: InfoWindow(
          title: title,
          snippet: description,
        ),
      ),
    );
  }

  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42, -122.08574),
    zoom: 14.4746,
  );

  //this controller will observe changes
  Completer<GoogleMapController> _controller = Completer();
  GoogleMapController? newGoogleMapController;

  // working of the geolocator package

  //getting parent device current location
  Position? parentCurrentLocation;
  var geoLocator =Geolocator();


  checkIfPermissionAllowed() async{
    LocationPermission permission;
    bool serviceEnabled;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // Permissions are denied, next time you could try
        // requesting permissions again (this is also where
        // Android's shouldShowRequestPermissionRationale
        // returned true. According to Android guidelines
        // your App should show an explanatory UI now.
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');

    }
    return serviceEnabled;
  }


  locateUserPosition() async {
    checkIfPermissionAllowed();
      //move camera along the lat long
      Position current_position =await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      parentCurrentLocation =current_position;

      LatLng latLngPosition =LatLng(current_position!.latitude,  current_position!.longitude);
      CameraPosition cameraPosition =CameraPosition(target: latLngPosition,zoom: 14);
      newGoogleMapController!.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));

      print('I am here in locate User Position');
  }

//Height of the white container that displays the safe zone for the child we have tapped
  double safeZoneContainerHeight = 220;

  _refresh_screen(){
    setState(() {

    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: _kGooglePlex,
            zoomControlsEnabled: true,
            zoomGesturesEnabled: true,
            mapType: MapType.normal,
            myLocationButtonEnabled: true,
            myLocationEnabled: true,
            compassEnabled: true,
            markers: Set<Marker>.of(_markers),
            onMapCreated: (GoogleMapController gmapController) {
              _controller.complete(gmapController);
              newGoogleMapController = gmapController;
              locateUserPosition();
              setState(() {
                _markers;
              });
            },
          ),

          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: AnimatedSize(
              curve: Curves.easeInSine,
              duration: const Duration(milliseconds: 120),
              child: Container(
                height: safeZoneContainerHeight,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(20),
                        topLeft: Radius.circular(20))),
                child: StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection('parents')
                      .doc(kfirebaseAuthenticationInstance.currentUser!.email.toString())
                      .collection('children')
                      .snapshots(),
                  builder: (BuildContext context,
                      AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>> snapshot) {
                    if (snapshot.hasData && snapshot.data != null) {
                      // to check total number of documents
                      debugPrint(
                          'Total Sub Collection Documents : ${snapshot.data!.docs.length}');

                      // checking if the collection has a data then come here
                      if (snapshot.data!.docs.isNotEmpty) {
                        //  make sure that document has the data
                        return ListView.separated(
                            itemBuilder: (_, int index) {
                              // **************** METHOD # 1 of FETCHING DATA ************************************************************
                              /*
                    * in method one we will dump the entire collection data
                    * */
                              Map<String, dynamic> docData = snapshot.data!.docs[index]
                                  .data(); // dump all the data in the docData map from the collection
                              // checking if the document is the emypt
                              if (docData.isEmpty) {
                                return Center(child: Text("Document is empty"));
                              }


                              LatLng? child_coordinates;
                              if(docData['current_geo_location'] !='NULL'){
                                child_coordinates = LatLng(
                                    docData['current_geo_location']['latitude'],
                                    docData['current_geo_location']['longitude']);

                                addNewSafeZoneMarker(index, child_coordinates, docData['child_name'], docData['child_email']);
                                print('index $index ${child_coordinates.toString()}');

                              }
                              return ListTile(
                                title: Text(docData['child_name']),
                                subtitle: Text('Current Geo Coordinates Are : ${child_coordinates == null ? "No Live Location Data ": child_coordinates.toString()}'),
                                trailing: Text(docData['child_pin']),
                                onTap: () async {
                                        setState(() {

                                        });
                                },

                                // if long press is trigger than delete the child from database and list tile view
                                onLongPress: () async {
                                  setState(() {});
                                },
                              );
                            },
                            separatorBuilder: (_, __) {
                              return const Divider();
                            },
                            itemCount: snapshot.data!.docs.length);
                      } else {
                        //document does not has data
                        return Center(
                          child: Text('Collection has no data'),
                        );
                      }
                    } else {
                      /*
              * if the collection does not has data flow come here and we will display no data to user on screen
              * */
                      return Center(
                        child: Text('Collection has no data'),
                      );
                    }
                  },
                ),
              ),
            ),
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: _refresh_screen,
        child: Icon(Icons.refresh_outlined),
      ),
    );
  }
}
