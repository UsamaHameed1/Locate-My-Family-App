import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../constants/constants.dart';
import '../../utils/Utils.dart';
import '../../widgets/form_input_field.dart';
import '../../widgets/progress_dialog.dart';
import '../mainScreens/main_screen.dart';

class AddChildTabPage extends StatefulWidget {
  const AddChildTabPage({Key? key}) : super(key: key);

  @override
  State<AddChildTabPage> createState() => _AddChildTabPageState();
}

class _AddChildTabPageState extends State<AddChildTabPage> {
  @override
  Widget build(BuildContext context) {
    TextEditingController nameTextEditingController = TextEditingController();
    TextEditingController ageTextEditingController = TextEditingController();
    TextEditingController emailTextEditingController = TextEditingController();
    TextEditingController pinTextEditingController = TextEditingController();

    saveChildInfo() {
      showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return ProgressDialog(message: 'Processing Please Wait.....');
          });

      // ********************** STRUCTURE OF THE CHIDLREN DOCUMENT **********************************************
      // Map childMap = {
      //   // 'parent_id': currentFirebaseUser!.uid,
      //   'child_name': nameTextEditingController.text.trim(),
      //   'child_email': emailTextEditingController.text.trim(),
      //   'child_age': ageTextEditingController.text.trim(),
      //   'child_pin': pinTextEditingController.text.trim(),
      // };
      // ********************************************************************************************************

      CollectionReference _referenceChildsDoc =
      parentDocumentReference!.collection('children');

      _referenceChildsDoc.doc(emailTextEditingController.text.trim()).set({
        // 'parent_id': kfirebaseCurrentUser!.uid,
        'child_name': nameTextEditingController.text.trim(),
        'child_email': emailTextEditingController.text.trim(),
        'child_age': ageTextEditingController.text.trim(),
        'child_pin': pinTextEditingController.text.trim(),
        'current_geo_location': 'NULL',
      }).then((value) {
        Navigator.pop(context);
        Utils().toastMessage("New Child Added");
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => MainScreen()));
      }).onError((error, stackTrace) {
        Utils().toastMessage("Error In Registration");
        Navigator.pop(context);
      });
    }

    validateForm() {
      if (nameTextEditingController.text.length < 3) {
        Utils().toastMessage("Name Must be larger than 3 characters");
      } else if (!emailTextEditingController.text.contains("@")) {
        Utils().toastMessage("Email is not valid");
      } else if (ageTextEditingController.text.isEmpty) {
        Utils().toastMessage("Age is mandatory");
      } else if (pinTextEditingController.text.isEmpty) {
        Utils().toastMessage("Pin is mandatory");
      } else {
        saveChildInfo();
      }
    }

    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            children: [
              //---------------------1st Spacer ------------------------------------
              const SizedBox(
                height: 10,
              ),

              //----------------------- 2nd Image ----------------------------------

              const Text(
                "Enter Your Child Details ",
                style: TextStyle(
                    fontSize: 24,
                    color: Colors.deepOrange,
                    fontWeight: FontWeight.bold),
              ),

              FormInputField(
                  nameTextEditingController: nameTextEditingController,
                  labelText: "Name",
                  hintText: "Name",
                  passwordFlag: false),
              FormInputField(
                  nameTextEditingController: ageTextEditingController,
                  labelText: "Age",
                  hintText: "Age",
                  passwordFlag: false),
              FormInputField(
                  nameTextEditingController: emailTextEditingController,
                  labelText: "Email",
                  hintText: "Email",
                  passwordFlag: false),
              FormInputField(
                  nameTextEditingController: pinTextEditingController,
                  labelText: "Pin For Login",
                  hintText: "Pin 1234",
                  passwordFlag: false),

              const SizedBox(
                height: 10,
              ),
              ElevatedButton(
                  onPressed: () {
                    validateForm();
                    Navigator.push(context,MaterialPageRoute(builder: (context) => MainScreen()));
                  },
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepOrange),
                  child: const Text(
                    "Add New Child Record",
                    style: TextStyle(fontSize: 18),
                  ))
            ],
          ),
        ),
      ),
    );
  }
}
