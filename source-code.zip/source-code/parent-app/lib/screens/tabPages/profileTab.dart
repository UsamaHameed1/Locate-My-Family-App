import 'package:flutter/material.dart';
import 'package:parents_app/constants/constants.dart';
import 'package:parents_app/screens/authentication/login_screen.dart';

class ParentsProfilePage extends StatelessWidget {
  const ParentsProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Logged In As : ${currentLoggedInParent!.name}'),
          const SizedBox(
            height: 10,
          ),
          Text('Registered Email : ${currentLoggedInParent!.email}'),
          const SizedBox(
            height: 10,
          ),
          Text('Password : ${currentLoggedInParent!.password}'),
          const SizedBox(
            height: 10,
          ),
          Text('Phone Number : ${currentLoggedInParent!.phone}'),
          const SizedBox(
            height: 10,
          ),
          const SizedBox(
            height: 25,
          ),
          ElevatedButton(
              onPressed: () {
                // signout the current user
                kfirebaseAuthenticationInstance.signOut();
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => LoginScreen()));
              },
              child: const Text("Logout "))
        ],
      ),
    );
  }
}
