import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:parents_app/model/parent.dart';
import 'package:parents_app/screens/authentication/child_register_screen_auth.dart';
import 'package:parents_app/utils/Utils.dart';
import 'package:parents_app/widgets/progress_dialog.dart';

import '../../constants/constants.dart';
import '../../dbHandler/FireStore_Important/firestoreCollectionNames.dart';
import '../../widgets/form_input_field.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({Key? key}) : super(key: key);

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  TextEditingController nameTextEditingController = TextEditingController();
  TextEditingController emailTextEditingController = TextEditingController();
  TextEditingController phoneTextEditingController = TextEditingController();
  TextEditingController passwordTextEditingController = TextEditingController();

  // BASIC FORM VALIDATION IS HERE
  void validateForm() {
    if (nameTextEditingController.text.length < 3) {
      Utils().toastMessage("Name Must be larger than 3 characters");
    } else if (!emailTextEditingController.text.contains("@")) {
      Utils().toastMessage("Email is not valid");
    } else if (phoneTextEditingController.text.isEmpty) {
      Utils().toastMessage("Phone is mandatory");
    } else if (passwordTextEditingController.text.length < 6) {
      Utils().toastMessage("Password must be of length greater than 6");
    } else {
      saveParentInfo();
    }
  }

  saveParentInfo() async {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return ProgressDialog(message: 'Processing Please Wait.....');
        });

    //----------------------trim will remove extra space -----------------------

    // ------------ creating a new user using the firebase authentication ------
    final _auth = (await kfirebaseAuthenticationInstance
        .createUserWithEmailAndPassword(
            email: emailTextEditingController.text.trim(),
            password: passwordTextEditingController.text.trim())
        .then((value) => Navigator.pop(context))
        .onError((error, stackTrace) => Navigator.pop(context)));

    final firebaseUser = kfirebaseAuthenticationInstance.currentUser;

    kfirebaseCurrentUserEmail = kfirebaseAuthenticationInstance.currentUser;

    if (firebaseUser != null) {
      Utils().toastMessage("Account has been created");

      // ----------- CREATING NEW PARENT OBJECT --------------------------------
      Parent newParent =Parent(name: nameTextEditingController.text.trim(), email: emailTextEditingController.text.trim(), phone: phoneTextEditingController.text.trim(), password: passwordTextEditingController.text.trim());

      //------------- entering data is the  fire store ---------------------------
      Map<String,dynamic> parentMap ={
        'id': firebaseUser.uid,
        'name': nameTextEditingController.text.trim(),
        'email': emailTextEditingController.text.trim(),
        'phone': phoneTextEditingController.text.trim(),
        'password': passwordTextEditingController.text.trim(),
      };

      final fireStoreParents = FirebaseFirestore.instance.collection(FireStoreCollectionNames.PARENTS_COLLECTION);
      fireStoreParents.doc(newParent.email).set(
          {
            'id': firebaseUser.uid,
            'name': nameTextEditingController.text.trim(),
            'email': emailTextEditingController.text.trim(),
            'phone': phoneTextEditingController.text.trim(),
            'password': passwordTextEditingController.text.trim(),
          }
      );
      // setting up the parent document reference for the registration of childs
      parentDocumentReference =FirebaseFirestore.instance.collection('parents').doc(parentMap['email']);

      Utils().toastMessage("Account has been created");
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => ChildRegisterScreen()));
    } else {
      Navigator.pop(context);
      Utils().toastMessage("Account has not been created");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          children: [
            //---------------------1st Spacer ------------------------------------
            const SizedBox(
              height: 10,
            ),

            //----------------------- 2nd Image ----------------------------------
            Padding(
              padding: const EdgeInsets.all(20),
              child: Image.asset("assets/images/family_logo_title.png"),
            ),

            const Text(
              "Register As Parent ",
              style: TextStyle(
                  fontSize: 24,
                  color: Colors.deepOrange,
                  fontWeight: FontWeight.bold),
            ),

            FormInputField(
                nameTextEditingController: nameTextEditingController,
                labelText: 'Name',
                hintText: "Name e.g Imran Khan",
                passwordFlag: false),
            FormInputField(
                nameTextEditingController: emailTextEditingController,
                labelText: 'Email',
                hintText: "abc@email.com",
                passwordFlag: false),
            FormInputField(
                nameTextEditingController: phoneTextEditingController,
                labelText: 'Phone',
                hintText: "+92 333 111 222",
                passwordFlag: true),
            FormInputField(
                nameTextEditingController: passwordTextEditingController,
                labelText: 'Password',
                hintText: "*********",
                passwordFlag: false),

            const SizedBox(
              height: 10,
            ),

            ElevatedButton(
                onPressed: () {
                  String name = nameTextEditingController.text;
                  String email = emailTextEditingController.text;
                  String phone = phoneTextEditingController.text;
                  String password = passwordTextEditingController.text;

                  validateForm();

                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) => ChildRegisterScreen()));
                },
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange),
                child: const Text(
                  "Sign Up - Create Account",
                  style: TextStyle(fontSize: 18),
                ))
          ],
        ),
      ),
    ));
  }
}
