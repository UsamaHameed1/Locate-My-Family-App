import 'package:flutter/material.dart';
import 'package:parents_app/screens/authentication/forget_password.dart';
import 'package:parents_app/screens/authentication/signup_screen.dart';
import 'package:parents_app/screens/mainScreens/main_screen.dart';
import 'package:parents_app/splashScreen/splash_screen.dart';

import '../../constants/constants.dart';
import '../../utils/Utils.dart';
import '../../widgets/form_input_field.dart';
import '../../widgets/progress_dialog.dart';

class LoginScreen extends StatelessWidget {
  TextEditingController emailTextEditingController = TextEditingController();
  TextEditingController passwordTextEditingController = TextEditingController();

  LoginScreen({super.key});

  void validateForm(BuildContext context) {
    if (!emailTextEditingController.text.contains("@")) {
      Utils().toastMessage("Email is not valid");
    } else if (!passwordTextEditingController.text.isNotEmpty) {
      Utils().toastMessage("Password must be required");
    } else {
      loginParent(context);
    }
  }

  void loginParent(BuildContext context) async {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return ProgressDialog(message: 'Processing Please Wait.....');
        });

    final _auth = (await kfirebaseAuthenticationInstance
        .signInWithEmailAndPassword(
            email: emailTextEditingController.text.trim(),
            password: passwordTextEditingController.text.trim())
        .then((value) => Navigator.push(
            context, MaterialPageRoute(builder: (context) => MainScreen())))
        .onError((error, stackTrace) {
          Utils().toastMessage("Login Failure "+ error.toString());
      Navigator.pop(context);
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => MySplashScreen()));
    }));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          children: [
            //---------------------1st Spacer ------------------------------------
            const SizedBox(
              height: 10,
            ),

            //----------------------- 2nd Image ----------------------------------
            Padding(
              padding: const EdgeInsets.all(20),
              child: Image.asset("assets/images/family_logo_title.png"),
            ),

            const Text(
              "Parent Login ",
              style: TextStyle(
                  fontSize: 24,
                  color: Colors.deepOrange,
                  fontWeight: FontWeight.bold),
            ),

            FormInputField(
                nameTextEditingController: emailTextEditingController,
                labelText: 'Email',
                hintText: "abc@email.com",
                passwordFlag: false),
            FormInputField(
                nameTextEditingController: passwordTextEditingController,
                labelText: 'Password',
                hintText: "**********",
                passwordFlag: true),

            const SizedBox(
              height: 10,
            ),

            ElevatedButton(
              onPressed: () {
                validateForm(context);
              },
              style:
                  ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange),
              child: const Text(
                "Login",
                style: TextStyle(fontSize: 18),
              ),
            ),
            TextButton(
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (context) => SignupPage())),
                child: Text('Donot have an account. Tap to sign up')),
            TextButton(onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
            }, child: Text('Forget Password'))
          ],
        ),
      ),
    ));
  }
}
