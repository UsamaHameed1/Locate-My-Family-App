import 'package:flutter/material.dart';
import 'package:parents_app/dbHandler/assistant_methods.dart';
import 'package:parents_app/screens/tabPages/addChildsPage.dart';
import 'package:parents_app/screens/tabPages/homeTab.dart';
import 'package:parents_app/screens/tabPages/profileTab.dart';
import 'package:parents_app/screens/tabPages/seeMapTab.dart';

import '../tabPages/ChatAppPage.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen>
    with SingleTickerProviderStateMixin {
  TabController? tabController;
  int selectedIndex = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    // load the details of the current logged in parent details
    AssistantMethods.readCurrentOnlineUserInfo();

    tabController = TabController(length: 5, vsync: this);
  }

  onItemClicked(int index) {
    setState(() {
      selectedIndex = index;
      tabController!.index = selectedIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
appBar: AppBar(
  title: Text("Parents App"),
  automaticallyImplyLeading: false,
),
      body: TabBarView(
        physics: NeverScrollableScrollPhysics(),
        controller: tabController,
        children: [
          HomeTabPage(),
          AddChildTabPage(),
          SeeMapTabPage(),
          ChatScreen(),
          ParentsProfilePage(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items:   [
          BottomNavigationBarItem(
              icon: Icon(
                Icons.home,
              ),
              label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.add,
              ),
              label: 'Add Child'),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.map_outlined,
              ),
              label: 'See Map'),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.chat_bubble,
              ),
              label: 'Chat App'),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.person,
              ),
              label: 'Profile'),
        ],
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: TextStyle(fontSize: 14),
        showUnselectedLabels: true,
        currentIndex: selectedIndex,
        onTap: onItemClicked,
      ),
    );
  }
}
