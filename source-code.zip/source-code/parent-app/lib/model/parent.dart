import 'package:cloud_firestore/cloud_firestore.dart';

import '../constants/constants.dart';
import '../dbHandler/FireStore_Important/firestoreDocumentNames.dart';

/*
*  WIll store the information of the user who is current logged in
*/
class Parent {
  String? name;
  String? email;
  String? password;
  String? phone;

  Parent({this.name, this.email, this.phone, this.password});

  Map<String, dynamic> generateParentMap() {
    return {
      'id': kfirebaseCurrentUserEmail.uid,
      'name': name,
      'email': email,
      'phone': password,
      'password': phone,
    };
  }

  Parent.fromFirestore(DocumentSnapshot snapshot) {
    final data = snapshot.data() as Map<String, dynamic>;
    name = data[DocumentFields.name];
    email = data[DocumentFields.email];
    password = data[DocumentFields.password];
    phone = data[DocumentFields.phone];
  }
}
