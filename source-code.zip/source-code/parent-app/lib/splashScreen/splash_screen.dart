import 'dart:async';
import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:parents_app/screens/authentication/login_screen.dart';
import 'package:parents_app/screens/mainScreens/main_screen.dart';

import '../constants/constants.dart';

/*
*   splash screen is a temporary screen that re-directs the users
*
*/

class MySplashScreen extends StatefulWidget {
  const MySplashScreen({Key? key}) : super(key: key);

  @override
  State<MySplashScreen> createState() => _MySplashScreenState();
}

class _MySplashScreenState extends State<MySplashScreen> {
  //
  startTimer() {
    /*
    *   after 3 seconds we will push the main screen to the user
    * */
    Timer(const Duration(seconds: 3), () async {
      // send the user to home screen
      if(kfirebaseAuthenticationInstance.currentUser !=null){
        // is the user is already logged in then login to the main screen directly
        kfirebaseCurrentUserEmail =kfirebaseAuthenticationInstance.currentUser!.email.toString();

        parentDocumentReference =FirebaseFirestore.instance.collection('parents').doc(kfirebaseAuthenticationInstance.currentUser!.email.toString());

        Navigator.push(context, MaterialPageRoute(builder: (context)=>MainScreen()));
      }
      else{
        // if not logged in then go to login screen
        Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen()));

      }
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        padding: EdgeInsets.all(20),
        color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            //  First Our LOGO
            Image.asset("assets/images/family_logo_title.png"),

            // Spacer
            SizedBox(
              height: 10,
            ),

            // Our Main Heading
            const Text(
              'Location Tracking App Parents View',
              style: TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                  fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
