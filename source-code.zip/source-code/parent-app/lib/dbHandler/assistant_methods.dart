import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:parents_app/constants/constants.dart';
import '../model/child.dart';
import '../model/parent.dart';

class AssistantMethods{
  static void readCurrentOnlineUserInfo() async{
    kfirebaseCurrentUserEmail =kfirebaseAuthenticationInstance.currentUser;
    
    DocumentReference parentUser =parentDocumentReference!;
    await parentUser.get().then((DocumentSnapshot snapshot){
      if(snapshot.exists){
        // if the snapshot exists then pass to the Parent class
        currentLoggedInParent=Parent.fromFirestore(snapshot);

        debugPrint('Name ${currentLoggedInParent!.name}');
      }
    });

  }

  static void readTappedChildInformation()async{

    kfirebaseCurrentUserEmail =kfirebaseAuthenticationInstance.currentUser;
    DocumentReference childDoc = childDocumentReference!;
    await childDoc.get().then((DocumentSnapshot snapshot){
      if(snapshot.exists){
        tappedChildObject = Child.fromFirestore(snapshot);
        debugPrint('Tapped Child Name ${tappedChildObject!.name}');
      }
    });


  }
}