package com.example.childs_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
