import 'dart:async';
import 'dart:ui';

import 'package:childs_app/utils/utils.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../constants/constants.dart';
import '../dbHandler/assistant_methods.dart';
import '../screens/authentication/login_screen.dart';
import '../screens/mainScreens/main_screen.dart';
import '../widgets/progress_dialog.dart';

/*
*   splash screen is a temporary screen that re-directs the users
*
*/

class MySplashScreen extends StatefulWidget {
  const MySplashScreen({Key? key}) : super(key: key);

  @override
  State<MySplashScreen> createState() => _MySplashScreenState();
}

class _MySplashScreenState extends State<MySplashScreen> {
  //
  startTimer() {

    //get the current child logged in email address first

    // after 3 seconds we will pus the main screen to the user
    Timer(const Duration(seconds:  3),() async{
      if (kfirebaseAuthenticationInstance.currentUser != null) {
        kfirebaseCurrentUserEmail =kfirebaseAuthenticationInstance.currentUser!.email;

        debugPrint('User is already Logged In');
        debugPrint('Current Firebase User Email Address : $kfirebaseCurrentUserEmail');

        (await getParentEmail(kfirebaseCurrentUserEmail));
        debugPrint('${kfirebaseCurrentUserEmail} ${kparentEmail}');

        showDialog(
            context: context,
            barrierDismissible: false,
            builder: (BuildContext context) {
              return ProgressDialog(message: 'Processing Please Wait.....');
            });


        Timer(Duration(seconds: 2),(){
          debugPrint('${kfirebaseCurrentUserEmail} ${kparentEmail}');
          parentDocumentReference = FirebaseFirestore.instance.collection('parents').doc(kparentEmail!);
          // getting the child document reference
          childDocumentReference = parentDocumentReference!.collection('children').doc(kfirebaseCurrentUserEmail);

          if(parentDocumentReference ==null || childDocumentReference ==null){
            debugPrint("Documents are null");
          }
          else{
            AssistantMethods.readParentInformation();
            AssistantMethods.readLoggedInChildInformation();
            debugPrint("Documents are not null");
            Navigator.pop(context);
            Utils().toastMessage("Login Success");
            Navigator.push(context, MaterialPageRoute(builder: (context) => MainScreen()));
          }
          });



      }
      else{
        Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen()));
      }
    });
  }

  getParentEmail(String childEmail) async {
    // get the parent document collection reference
    var parentCollectionReference =
        FirebaseFirestore.instance.collection('parents');

    //going to each parent document
    await parentCollectionReference.get().then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        // now going to each parent document children collection
        var parentDocumentReference =
            parentCollectionReference.doc(doc['email']);

        var childrenCollectionReference =
            parentDocumentReference.collection('children');
        childrenCollectionReference
            .get()
            .then((QuerySnapshot childQuerySnapshot) {
          childQuerySnapshot.docs.forEach((chidDoc) {
            if (chidDoc['child_email'] == childEmail) {
              kparentEmail = doc['email'].toString();
              print(kparentEmail);
              return;
            }
          });
        });
      });
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        padding: EdgeInsets.all(20),
        color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            //  First Our LOGO
            Image.asset("assets/images/family_logo_title.png"),

            // Spacer
            SizedBox(
              height: 10,
            ),

            // Our Main Heading
            const Text(
              'Location Tracking App Parents View',
              style: TextStyle(
                  fontSize: 20,
                  color: Colors.black,
                  fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
