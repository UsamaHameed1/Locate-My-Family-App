import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../constants/constants.dart';
import '../model/child.dart';
import '../model/parent.dart';

class AssistantMethods{
  static void readParentInformation() async{
    kfirebaseCurrentUserEmail =kfirebaseAuthenticationInstance.currentUser;

    DocumentReference parentUser =parentDocumentReference!;
    await parentUser.get().then((DocumentSnapshot snapshot){
      if(snapshot.exists){
        // if the snapshot exists then pass to the Parent class
        parentObject=Parent.fromFirestore(snapshot);

        debugPrint('Name ${parentObject!.name}');
      }
    });

  }

  static void readLoggedInChildInformation()async{

    kfirebaseCurrentUserEmail =kfirebaseAuthenticationInstance.currentUser;
    DocumentReference childDoc = childDocumentReference!;
    await childDoc.get().then((DocumentSnapshot snapshot){
      if(snapshot.exists){
        loggedInChild = Child.fromFirestore(snapshot);
        debugPrint('Tapped Child Name ${loggedInChild!.name}');
      }
    });


  }
}