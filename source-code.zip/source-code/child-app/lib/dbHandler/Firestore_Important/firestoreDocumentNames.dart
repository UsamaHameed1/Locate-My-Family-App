class DocumentFields {
  static const String email = 'email';
  static const String id = 'id';
  static const String password = 'password';
  static const String phone = 'phone';
  static const String name = 'name';

  static const String child_age = 'child_age';
  static const String child_email = 'child_email';
  static const String child_name = 'child_name';
  static const String child_pin = 'child_pin';

  static const String safezone_description = 'description';
  static const String safezone_latitude = 'lat';
  static const String safezone_longitude = 'long';
  static const String safezone_title = 'title';
}
