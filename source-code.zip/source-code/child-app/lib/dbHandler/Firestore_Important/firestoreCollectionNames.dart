class FireStoreCollectionNames{
  static const String PARENTS_COLLECTION ='parents';
  static const String CHILDREN_COLLECTION ='children';
  static const String CHILD_SAFE_ZONE_COLLECTION ='safe-zones';
}