import 'package:flutter/material.dart';

class FormInputField extends StatelessWidget {
  const FormInputField({
    Key? key,
    required this.nameTextEditingController,
    required this.labelText,
    required this.hintText,
    required this.passwordFlag,       // this will be used to determin if the field is password like or a simple filed
  }) : super(key: key);

  final TextEditingController nameTextEditingController;
  final labelText;
  final hintText;
  final passwordFlag;

  @override
  Widget build(BuildContext context) {
    return TextField(
      keyboardType: passwordFlag ? TextInputType.number: TextInputType.text,
      controller: nameTextEditingController,
      decoration: InputDecoration(
          labelText: labelText,
          hintText: hintText,
          enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.green)),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.green)),
          hintStyle: TextStyle(color: Colors.black, fontSize: 10),
          labelStyle: TextStyle(color: Colors.black, fontSize: 15)),
    );
  }
}
