import 'dart:async';

import 'package:childs_app/screens/mainScreens/main_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../constants/constants.dart';
import '../../utils/utils.dart';
import '../../widgets/form_input_field.dart';
import '../../widgets/progress_dialog.dart';

class LoginScreen extends StatelessWidget {
  TextEditingController emailTextEditingController = TextEditingController();
  TextEditingController pinTextEditingController = TextEditingController();
  TextEditingController parentEmailTextEditingController =
      TextEditingController();

  LoginScreen({super.key});

  void validateForm(BuildContext context) {
    if (!emailTextEditingController.text.contains("@")) {
      Utils().toastMessage("Email is not valid");
    } else if (!pinTextEditingController.text.isNotEmpty) {
      Utils().toastMessage("pin must be required");
    } else {
      loginChild(context);
    }
  }

  void loginChild(BuildContext context) async {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return ProgressDialog(message: 'Processing Please Wait.....');
        });

    // check if the child details exist or not
    var parentDocumentReference = FirebaseFirestore.instance
        .collection('parents')
        .doc(parentEmailTextEditingController.text.trim());
    parentDocumentReference.get().then((DocumentSnapshot documentSnapshot) {
      final data = documentSnapshot.data() as Map<String, dynamic>;
      if (data['email'] == parentEmailTextEditingController.text.trim()) {
        debugPrint("parent founded");

        // checking for the children details
        var childrenDocumentRefernce = FirebaseFirestore.instance
            .collection('parents')
            .doc(parentEmailTextEditingController.text.trim())
            .collection('children')
            .doc(emailTextEditingController.text.trim());
        childrenDocumentRefernce
            .get()
            .then((DocumentSnapshot childrenDocumentSnapshot) async {
          final childrenData =
              childrenDocumentSnapshot.data() as Map<String, dynamic>;
          if (childrenData['child_email'] ==
                  emailTextEditingController.text.trim() &&
              childrenData['child_pin'] ==
                  pinTextEditingController.text.trim()) {
            debugPrint('children also found ${childrenData['child_email']}');
            kfirebaseCurrentUserEmail =
                parentEmailTextEditingController.text.trim();
            kcurrentChildEmail = emailTextEditingController.text.trim();

            //now register child in the firebase authentication too
            final _auth = (await kfirebaseAuthenticationInstance
                .createUserWithEmailAndPassword(
                    email: emailTextEditingController.text.trim(),
                    password: pinTextEditingController.text.trim())
                .then((value) {
              kparentEmail = parentEmailTextEditingController.text.toString();
              kcurrentChildEmail = emailTextEditingController.text.toString();

              Navigator.pop(context);

              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => MainScreen()));
            }).onError((error, stackTrace) async {

              // --- if child is logging in other than first time the this process will be followed because
              // he is already registered in the firebase authentication system
              Utils().toastMessage(error.toString());

              final _auth2 = (await kfirebaseAuthenticationInstance
                  .signInWithEmailAndPassword(
                      email: emailTextEditingController.text.trim(),
                      password: pinTextEditingController.text.trim())
                  .then(((value) {

                Utils().toastMessage('Login Sucessfull');



                Navigator.pop(context);

                kparentEmail = parentEmailTextEditingController.text.toString();
                kcurrentChildEmail = emailTextEditingController.text.toString();
                getDocuments(kcurrentChildEmail);

                // getting parent document reference
                parentDocumentReference =
                    FirebaseFirestore.instance.collection('parents').doc(kparentEmail);

                debugPrint(parentDocumentReference.toString());

                // getting the child document reference
                childDocumentReference =
                    parentDocumentReference.collection('children').doc(
                        kcurrentChildEmail);

                debugPrint(childDocumentReference.toString());
                debugPrint('child email address login page${kcurrentChildEmail.toString()}');
                debugPrint('parent email address login page${kparentEmail.toString()}');


                Timer(const Duration(seconds: 3),(){


                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => MainScreen()));
                });

              })));
            }));

            kfirebaseCurrentUserEmail =
                kfirebaseAuthenticationInstance.currentUser!.email.toString();
          } else {
            Navigator.pop(context);
            Utils().toastMessage("Child Email or Pin is Invalid");
          }
        });
      } else {
        Navigator.pop(context);
        Utils().toastMessage("Parents Email Not Registered");
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Child App'),
        automaticallyImplyLeading: false,
      ),
        body: SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          children: [
            //---------------------1st Spacer ------------------------------------
            const SizedBox(
              height: 10,
            ),

            //----------------------- 2nd Image ----------------------------------
            Padding(
              padding: const EdgeInsets.all(20),
              child: Image.asset("assets/images/family_logo_title.png"),
            ),

            const Text(
              "Child`s Login ",
              style: TextStyle(
                  fontSize: 24,
                  color: Colors.deepOrange,
                  fontWeight: FontWeight.bold),
            ),

            FormInputField(
                nameTextEditingController: emailTextEditingController,
                labelText: 'Child Email',
                hintText: "abc@email.com",
                passwordFlag: false),

            FormInputField(
                nameTextEditingController: parentEmailTextEditingController,
                labelText: 'Parent Email',
                hintText: "abc@email.com",
                passwordFlag: false),

            FormInputField(
                nameTextEditingController: pinTextEditingController,
                labelText: 'Pin',
                hintText: "**********",
                passwordFlag: true),

            const SizedBox(
              height: 10,
            ),

            ElevatedButton(
              onPressed: () {
                validateForm(context);
              },
              style:
                  ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange),
              child: const Text(
                "Login",
                style: TextStyle(fontSize: 18),
              ),
            ),
            Text('Do not Have Any Account Ask Your Parents To Register')
          ],
        ),
      ),
    ));
  }

  getDocuments(String childEmail) async {
    // get the parent document collection reference
    var parentCollectionReference = FirebaseFirestore.instance.collection(
        'parents');

    //going to each parent document
    await parentCollectionReference.get().then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        // now going to each parent document children collection
        var parentDocumentReference = parentCollectionReference.doc(
            doc['email']);


        var childrenCollectionReference = parentDocumentReference.collection(
            'children');
        childrenCollectionReference.get().then((
            QuerySnapshot childQuerySnapshot) {
          childQuerySnapshot.docs.forEach((chidDoc) {
            if (chidDoc['child_email'] == childEmail) {
              kparentEmail = doc['email'].toString();
              print(kparentEmail);
            }
          });
        });
      });
    });
  }
}
