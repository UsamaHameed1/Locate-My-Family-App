import 'package:childs_app/screens/chat_app/chat_screen.dart';
import 'package:flutter/material.dart';

class ChatAppTabPage extends StatelessWidget {
  const ChatAppTabPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChatScreen();
  }
}
