import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart' as loc;
import 'package:url_launcher/url_launcher.dart';

import '../../../constants/constants.dart';
import '../../../dbHandler/Firestore_Important/firestoreCollectionNames.dart';
import '../../../dbHandler/Firestore_Important/firestoreDocumentNames.dart';
import '../../../utils/utils.dart';

class HomeTabPage extends StatefulWidget {
  const HomeTabPage({Key? key}) : super(key: key);

  @override
  State<HomeTabPage> createState() => _HomeTabPageState();
}

class _HomeTabPageState extends State<HomeTabPage> {
  // =================== implementation of live location sharing ====================================================================
  final loc.Location location = loc.Location();
  StreamSubscription<loc.LocationData>? _locationSubscription;

  _updateLocation() async {
    try {
      final loc.LocationData _locationResult = await location.getLocation();
      await childDocumentReference?.update({
        'current_geo_location': {
          'latitude': _locationResult.latitude,
          'longitude': _locationResult.longitude,
        }
      });
    }
    catch (e) {
      print(e);
    }
  }


  Future<void> _listenLocation() async {
    /*
    *   When ever my location changes than a change will be recvied here and which will update the geo coordinates
    * */
    _locationSubscription = location.onLocationChanged.handleError((onError) {
      print(onError);
      _locationSubscription?.cancel();
      setState(() {
        _locationSubscription = null;
      });
    }).listen((loc.LocationData currentlocation) async {
      print('Changed Location : ${currentlocation.longitude}');
      await childDocumentReference!.update({
        'current_geo_location': {
          'latitude': currentlocation.latitude,
          'longitude': currentlocation.longitude,
        }
      });
    });
  }
  // ========================= Adding the Custom Maker for each of the safe zone added for the child ==============================
  final List<Marker> _markers = <Marker>[];
  final List<LatLng> _latLang = <LatLng>[];

  // add new marker
  addNewSafeZoneMarker(
      int index, LatLng safeZoneCoordinates, String title, description) {
    _markers.add(Marker(
        markerId: MarkerId(index.toString()),
        position: safeZoneCoordinates,
        infoWindow: InfoWindow(
          title: title,
          snippet: description,
        )));
  }

  popSafeZoneMarker(int index) {
    _markers.removeAt(index);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    checkIfPermissionAllowed();
    debugPrint('Parent Email : ${parentObject?.email}');
    debugPrint('Child Email : ${loggedInChild?.email}');
  }

  // for testing only
  static const CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(33.6910, 72.98072),
    zoom: 15,
  );

  //Setting up the google map controller that will listen to the changes occurring in the google map
  Completer<GoogleMapController> _controller = Completer();
  GoogleMapController? newGoogleMapController;

  //Height of the white container that displays the safe zone for the child we have tapped
  double safeZoneContainerHeight = 220;

  //------------- Stuff Related To Safe Zone Marker ----------------------------

  // this object store the current position of the parent device
  Position? parentCurrentLocation;

  // initialing the Geo Locator Package Object
  var geoLocator = Geolocator();

  // Location permission instance
  LocationPermission? _locationPermission;

  //getting user permission for the location services
  checkIfPermissionAllowed() async {
    LocationPermission permission;
    bool serviceEnabled;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // Permissions are denied, next time you could try
        // requesting permissions again (this is also where
        // Android's shouldShowRequestPermissionRationale
        // returned true. According to Android guidelines
        // your App should show an explanatory UI now.
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    return serviceEnabled;
  }

  // get the user current geo coordinates
  locateUserPosition() async {
    checkIfPermissionAllowed();
    //move camera along the lat long
    Position current_position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    parentCurrentLocation = current_position;

    debugPrint("My Current Location is ${current_position.longitude}");

    LatLng latLngPosition =
        LatLng(current_position!.latitude, current_position!.longitude);
    CameraPosition cameraPosition =
        CameraPosition(target: latLngPosition, zoom: 14);
    newGoogleMapController!
        .animateCamera(CameraUpdate.newCameraPosition(cameraPosition));

    _updateLocation();
    _listenLocation();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          //Google Maps Widget Start here
          GoogleMap(
            initialCameraPosition: _kGooglePlex,
            mapType: MapType.normal,
            myLocationButtonEnabled: true,
            myLocationEnabled: true,
            compassEnabled: true,
            markers: Set<Marker>.of(_markers),
            onMapCreated: (GoogleMapController gmapController) {

              _controller.complete(gmapController);
              newGoogleMapController = gmapController;
              locateUserPosition();

              setState(() {

              });
            },
          ),

          // Safe Zone Bottom Container Starts From Here
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: AnimatedSize(
              curve: Curves.easeInSine,
              duration: const Duration(milliseconds: 120),
              child: Container(
                height: safeZoneContainerHeight,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(20),
                        topLeft: Radius.circular(20))),
                child: StreamBuilder(
                  stream: childDocumentReference!
                      .collection(
                          FireStoreCollectionNames.CHILD_SAFE_ZONE_COLLECTION)
                      .snapshots(),
                  builder: (BuildContext context,
                      AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>>
                          snapshot) {
                    if (snapshot.hasData && snapshot.data != null) {
                      // to check total number of documents
                      debugPrint('===================>${childDocumentReference}');
                      debugPrint(
                          'Total Sub Collection Documents Safe Zone : ${snapshot.data!.docs.length}');

                      // checking if the collection has a data then come here
                      if (snapshot.data!.docs.isNotEmpty) {
                        //  make sure that document has the data
                        return ListView.separated(
                            itemBuilder: (_, int index) {
                              // **************** METHOD # 1 of FETCHING DATA ************************************************************
                              /*
                                * in method one we will dump the entire collection data
                                * */
                              Map<String, dynamic> docData = snapshot
                                  .data!.docs[index]
                                  .data(); // dump all the data in the docData map from the collection
                              // checking if the document is the emypt
                              if (docData.isEmpty) {
                                setState(() {

                                });
                                return const Center(
                                    child: Text("Document is empty"));
                              }

                              // add the loaded safe zone the the markers list
                              LatLng coordinates = LatLng(
                                  double.parse(docData[
                                      DocumentFields.safezone_latitude]),
                                  double.parse(docData[
                                      DocumentFields.safezone_longitude]));
                              addNewSafeZoneMarker(
                                  index,
                                  coordinates,
                                  docData[DocumentFields.safezone_title],
                                  docData[DocumentFields.safezone_description]);

                              return ListTile(
                                title: Text(
                                    docData[DocumentFields.safezone_title]),
                                subtitle: Text(
                                    '${docData[DocumentFields.safezone_description]} \nLatitude ${docData[DocumentFields.safezone_latitude]} and Longitude ${docData[DocumentFields.safezone_longitude]} '),
                                trailing: const Icon(Icons.location_on),
                                onTap: () async {
                                  double lat = double.parse(docData[
                                      DocumentFields.safezone_latitude]);

                                  double long = double.parse(docData[
                                      DocumentFields.safezone_longitude]);

                                  LatLng latLngPosition = LatLng(lat, long);
                                  debugPrint(
                                      latLngPosition.longitude.toString());
                                  CameraPosition cameraPosition =
                                      CameraPosition(
                                          target: latLngPosition, zoom: 14);
                                  newGoogleMapController!.animateCamera(
                                      CameraUpdate.newCameraPosition(
                                          cameraPosition));

                                  debugPrint(index.toString());
                                  setState(() {});
                                },
                              );
                            },
                            separatorBuilder: (_, __) {
                              return const Divider();
                            },
                            itemCount: snapshot.data!.docs.length);
                      } else {
                        //document does not has data
                        return const Center(
                          child:
                              Text('No Safe Zone is added by the parent yet'),
                        );
                      }
                    } else {
                      /*
              * if the collection does not has data flow come here and we will display no data to user on screen
              * */
                      return const Center(
                        child: Text('No Safe Zone is added by the parent yet'),
                      );
                    }
                  },
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.sos),
        onPressed: () async {
          Utils().toastMessage("Sending SOS Alert On SMS Carier");
          String sos_msg =
              'Hello I am ${loggedInChild!.name} and i am not feeling safe and that`s why i am sending this SOS message to you via Locate My Family App';
          String parent_mobile_number = parentObject!.phone!;
          Uri sms = Uri.parse('sms:${parent_mobile_number}?body=${sos_msg}');
          if (await launchUrl(sms)) {
          } else {
            //app is not opened
          }
        },
      ),
    );
  }
}
