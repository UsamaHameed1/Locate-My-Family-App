import 'package:flutter/material.dart';

import '../../../constants/constants.dart';
import '../../authentication/login_screen.dart';

class ProfileTabPage extends StatelessWidget {
  const ProfileTabPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Child Profile Information',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(
            height: 15,
          ),
          // Child Information Card
          Container(
            width: 300,
            height: 200,
            child: Card(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 10,),

                  Text('Logged In Child Name: ${loggedInChild!.name}'),
                  SizedBox(height: 10,),

                  Text('Child Age: ${loggedInChild!.age}'),
                  SizedBox(height: 10,),

                  Text('Child Email: ${loggedInChild!.email}'),
                  SizedBox(height: 10,),

                  Text('Child Password: ${loggedInChild!.pin}'),
                  SizedBox(height: 10,),

                ],
              ),
            ),
          ),
          Text(
            'Parent Profile Information',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(
            height: 15,
          ),
          // Parent Information Card
          Container(
            width: 300,
            height: 200,
            child: Card(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 10,),
                  Text('Logged In Child Parent Name: ${parentObject!.name}'),
                  SizedBox(height: 10,),
                  Text('Parent Mobile No: ${parentObject!.phone}'),
                  SizedBox(height: 10,),
                  Text('Parent Email: ${parentObject!.email}'),
                  SizedBox(height: 10,),

                ],
              ),
            ),
          ),

          ElevatedButton(
              onPressed: () {
                // signout the current user
                kfirebaseAuthenticationInstance.signOut();
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => LoginScreen()));
              },
              child: Text("Logout Child Account"))
        ],
      ),
    );
  }
}
