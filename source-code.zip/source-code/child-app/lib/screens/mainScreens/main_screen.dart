import 'package:childs_app/dbHandler/assistant_methods.dart';
import 'package:childs_app/screens/mainScreens/tabPages/chat_app_tab_page.dart';
import 'package:childs_app/screens/mainScreens/tabPages/home_tab_pages.dart';
import 'package:childs_app/screens/mainScreens/tabPages/profile_tab_page.dart';
import 'package:flutter/material.dart';

import '../../constants/constants.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen>
    with SingleTickerProviderStateMixin {
  TabController? tabController;
  int selectedIndex = 0;

  void initState() {
    // TODO: implement initState
    super.initState();
    // AssistantMethods.readCurrentOnlineUserInfo();
    // AssistantMethods.readTappedChildInformation();


    AssistantMethods.readParentInformation();
    AssistantMethods.readLoggedInChildInformation();
    tabController = TabController(length: 3, vsync: this);
  }

  onItemClicked(int index) {
    setState(() {
      selectedIndex = index;
      tabController!.index = selectedIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Child App View"),
        automaticallyImplyLeading: false,
      ),
      body: TabBarView(
        physics: NeverScrollableScrollPhysics(),
        controller: tabController,
        children: const [
          HomeTabPage(),
          ChatAppTabPage(),
          ProfileTabPage(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
              icon: Icon(
                Icons.location_on,
              ),
              label: 'My Map'),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.chat_bubble,
              ),
              label: 'Chat App'),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.person,
              ),
              label: 'Child Profile'),
        ],
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: TextStyle(fontSize: 14),
        showUnselectedLabels: true,
        currentIndex: selectedIndex,
        onTap: onItemClicked,
      ),
    );
  }
}
