import 'package:cloud_firestore/cloud_firestore.dart';

import '../dbHandler/Firestore_Important/firestoreDocumentNames.dart';

class Child{
  String? name;
  String? email;
  String? age;
  String? pin;

  Child({ this.name,  this.age, this.pin,  this.email});

  Child.fromFirestore(DocumentSnapshot snapshot) {
    final data = snapshot.data() as Map<String, dynamic>;
    name = data[DocumentFields.child_name];
    email = data[DocumentFields.child_email];
    pin = data[DocumentFields.child_pin];
    age = data[DocumentFields.child_age];
  }
}